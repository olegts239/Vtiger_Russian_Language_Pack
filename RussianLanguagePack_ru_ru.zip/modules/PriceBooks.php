<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is: EntExt
 * The Initial Developer of the Original Code is EntExt.
 * All Rights Reserved.
 * If you have any questions or comments, please email: devel@entext.com
 ************************************************************************************/
$languageStrings = array(
    'PriceBooks'                   => 'Каталоги'            ,
    'SINGLE_PriceBooks'            => 'Каталог'              ,
    'LBL_ADD_RECORD'               => 'Добавить Каталог',
    'LBL_RECORDS_LIST'             => 'Список Каталогов',
    'LBL_PRICEBOOK_INFORMATION'    => 'Информация о Каталоге',
    'LBL_EDIT_LIST_PRICE'          => 'Редактировать список цен'             ,
    'Price Book Name'              => 'Название'            ,
    'PriceBook No'                 => 'Каталог №'          ,

    'LBL_UNIT_PRICE' => 'Цена за штуку',
	'LBL_ADD_TO' => 'Добавлять к',
);
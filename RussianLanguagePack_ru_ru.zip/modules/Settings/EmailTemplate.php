<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is: EntExt
 * The Initial Developer of the Original Code is EntExt.
 * All Rights Reserved.
 * If you have any questions or comments, please email: devel@entext.com
 ************************************************************************************/
$languageStrings = array(
    'EmailTemplate'                => 'Шаблон E-mail'          , // KEY 5.x: LBL_EMAIL_TEMPLATE
    'LBL_TEMPLATE_NAME'            => 'Имя шаблона'               ,
    'LBL_DESCRIPTION'              => 'Описание'            ,
    'LBL_SUBJECT'                  => 'Тема'                    ,
);
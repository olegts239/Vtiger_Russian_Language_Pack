<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.1
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is: EntExt
 * The Initial Developer of the Original Code is EntExt.
 * All Rights Reserved.
 * If you have any questions or comments, please email: devel@entext.com
 ************************************************************************************/
$languageStrings = array(
    'CustomerPortal'               => 'Клиентский портал',
    'LBL_PORTAL_DESCRIPTION'       => 'Установка прав пользователя портала',
    'LBL_PRIVILEGES'               => 'Профили пользователей',
    'LBL_DEFAULT_ASSIGNEE'         => 'Правопреемник по умолчанию',
    'LBL_PORTAL_URL'               => 'URL портала',
    'LBL_MODULE_NAME'              => 'Имя модуля',
    'LBL_ENABLE_MODULE'            => 'Включить модуль',
    'LBL_VIEW_ALL_RECORDS'         => 'Смотреть все связанные записи?',
    'LBL_PREVILEGES_MESSAGE'       => 'ПРИМЕЧАНИЕ: Профиль пользователя будет выбран для управления полями, которые появляются в Клиентском портале.',
    'LBL_DEFAULT_ASSIGNEE_MESSAGE' => 'ПРИМЕЧАНИЕ: Заявкам от клиентов Портала будет назначен, по умолчанию, выбранный правопреемник Группы/Пользователя.',
    'LBL_PORTAL_URL_MESSAGE'       => 'ПРИМЕЧАНИЕ: URL портала где ваши клиенты могут создавать/отслеживать заявки, иметь доступ к базе знаний и т.д. Контакту отправятся логин и пароль для доступа к порталу, если у него в карточке есть подписка на услуги Клиентского портала.',
    'LBL_DRAG_AND_DROP_MESSAGE'    => 'Перетаскивайте модули, чтобы изменить их нумерацию в Клиентском портале',
);
$jsLanguageStrings = array(
	'JS_PORTAL_INFO_SAVED'         => 'Настройки Клиентского портала сохранены',
);